package me.hellonayeon.backend.comment.dto.request;

public class UpdateCommentRequest {

    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
