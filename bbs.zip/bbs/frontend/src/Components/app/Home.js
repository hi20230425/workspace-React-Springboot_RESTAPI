
function Home() {
	return (
		<div>
			<h2> 게시판 Home 입니다. </h2>
		</div>
	);
}

export default Home;